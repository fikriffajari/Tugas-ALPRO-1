#include <stdio.h>

int main() {
    printf("|======================================|\n");
    printf("|               Osiloskop              |\n");
    printf("|      Alat ukur bentuk gelombang      |\n");
    printf("|       Tegangan terhadap waktu        |\n");
    printf("|======================================|\n");
    return 0;
}