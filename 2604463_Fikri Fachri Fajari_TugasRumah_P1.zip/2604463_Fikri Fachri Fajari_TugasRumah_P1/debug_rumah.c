#include <stdio.h>

int main() {
 printf("Latihan Mandiri\n");
 printf("Topik: Pengantar Pemrograman C\n");
 printf("Semoga lancar!\n");
 printf("Sampai jumpa\n");
 return 0;
}

/*
1.diakhir baris ke 5 tidak ada ";", cara memperbaikinya yaitu dengan menambahkan ";" di akhir baris
2.diawal baris ke 6 PRINTF nya kapital, cara memperbaikinya yaitu dengan mengganti "PRINTF" dengan "printf"
3.dibaris ke 7 tanda petik tunggal yang pertama harusnya tanda petik ganda, cara memperbaikinya yaitu dengan mengganti tanda petik tunggal menjadi tanda petik ganda
*/