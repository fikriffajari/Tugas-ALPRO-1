#include <stdio.h>

int main() {
    printf("=================================================================\n");
    printf("|                           BIODATA                             |\n");
    printf("|===============================================================|\n");
    printf("| Nama Lengkap  : Fikri Fachri Fajari                           |\n");
    printf("| NIM           : 2604463                                       |\n");
    printf("|---------------------------------------------------------------|\n");
    printf("| Program Studi : Teknik Elektro                                |\n");
    printf("| Fakultas      : FPTI                                          |\n");
    printf("|---------------------------------------------------------------|\n");
    printf("| Asal Sekolah   : SMAN 1 Banjar                                |\n");
    printf("| Alasan Memilih : Memiliki minat dalam hal elektro yang dimana |\n");
    printf("|     barang barangnya dapat ditemukan di kehidupan sehari hari |\n");
    printf("|---------------------------------------------------------------|\n");
    printf("| Mata Kuliah Favorit   : Aljabar Linear                        |\n");
    printf("=================================================================\n");

    return 0;
}